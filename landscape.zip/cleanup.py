from database.db import SessionLocal
from database.models import LandscapeItem
import os

def clear_landscape():
    session = SessionLocal()
    try:
        # 1. Delete all records from the database
        num_rows = session.query(LandscapeItem).delete()
        session.commit()
        print(f"Deleted {num_rows} records from the database.")

        # 2. (Optional) Clear the physical images from uploads/landscape
        # This keeps your disk clean too!
        folder = os.path.join(os.getcwd(), "uploads", "landscape")
        if os.path.exists(folder):
            for filename in os.listdir(folder):
                file_path = os.path.join(folder, filename)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception as e:
                    print(f"Failed to delete {file_path}: {e}")
            print("Physical upload folder cleared.")

    except Exception as e:
        print(f"Error: {e}")
        session.rollback()
    finally:
        session.close()

if __name__ == "__main__":
    clear_landscape()