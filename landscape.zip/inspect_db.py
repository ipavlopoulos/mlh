import sqlite3
from database.db import DB_PATH

print("Inspecting database:", DB_PATH)

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
print("Tables:", cur.fetchall())

cur.execute("SELECT COUNT(*) FROM proverb_types;")
print("Proverb types count:", cur.fetchone()[0])

cur.execute("SELECT COUNT(*) FROM proverb_attestations;")
print("Proverb attestations count:", cur.fetchone()[0])

print("\nSample proverb types:")
cur.execute("SELECT id, text, language FROM proverb_types LIMIT 5;")
for row in cur.fetchall():
    print(row)

print("\nSample attestations:")
cur.execute("""
    SELECT id, proverb_id, location, collector, external_id
    FROM proverb_attestations
    LIMIT 5;
""")
for row in cur.fetchall():
    print(row)

conn.close()