import os
import uuid
from flask import Flask, render_template, request, send_from_directory, flash, redirect, url_for
from werkzeug.utils import secure_filename

from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS

from geopy.geocoders import Nominatim

from database.db import engine, Base
from database.landscape_repository import add_landscape_item, get_all_landscape_items

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")

app = Flask(__name__)
app.secret_key = "supersecretkey"

app.config["UPLOADS_ROOT"] = UPLOAD_DIR
app.config["LANDSCAPE_FOLDER"] = os.path.join(UPLOAD_DIR, "landscape")

os.makedirs(app.config["LANDSCAPE_FOLDER"], exist_ok=True)

# DB init
with app.app_context():
    import database.models
    Base.metadata.create_all(bind=engine)


# -------------------------
# EXIF HELPERS
# -------------------------
def get_exif_data(image_path):
    try:
        image = Image.open(image_path)
        exif_data = image.getexif()

        if not exif_data:
            return {}

        data = {}

        for tag_id, value in exif_data.items():
            tag = TAGS.get(tag_id, tag_id)

            if tag == "GPSInfo":
                gps_data = {}
                for t in value:
                    gps_data[GPSTAGS.get(t, t)] = value[t]
                data["GPSInfo"] = gps_data
            else:
                data[tag] = value

        return data

    except Exception:
        return {}


def get_coordinates(exif):
    gps = exif.get("GPSInfo")
    if not gps:
        return None

    def to_float(x):
        try:
            if isinstance(x, tuple):
                return float(x[0]) / float(x[1])
            return float(x)
        except:
            return 0.0

    def convert(vals):
        try:
            d = to_float(vals[0])
            m = to_float(vals[1])
            s = to_float(vals[2])
            return d + (m / 60) + (s / 3600)
        except:
            return None

    try:
        lat = convert(gps.get("GPSLatitude"))
        lon = convert(gps.get("GPSLongitude"))

        if lat is None or lon is None:
            return None

        if gps.get("GPSLatitudeRef") != "N":
            lat = -lat
        if gps.get("GPSLongitudeRef") != "E":
            lon = -lon

        return lat, lon

    except Exception:
        return None


# -------------------------
# REVERSE GEOCODING
# -------------------------
def reverse_geocode(lat, lon):
    try:
        geolocator = Nominatim(user_agent="landscape_app")
        location = geolocator.reverse((lat, lon), language="en")

        if not location:
            return None, None, None

        address = location.raw.get("address", {})

        country = address.get("country")
        city = address.get("city") or address.get("town") or address.get("village")
        street = address.get("road")

        return country, city, street

    except Exception:
        return None, None, None


# -------------------------
# ROUTE
# -------------------------
@app.route("/", methods=["GET", "POST"])
def landscape():
    error = None

    if request.method == "POST":
        file = request.files.get("image")

        country = request.form.get("country")
        city = request.form.get("city")
        street = request.form.get("street")

        content_type = request.form.get("content_type", "")
        transcription = request.form.get("transcription", "")
        comments = request.form.get("comments", "")

        if not file:
            error = "Image is required."
        else:
            try:
                filename = f"{uuid.uuid4()}_{secure_filename(file.filename)}"
                filepath = os.path.join(app.config["LANDSCAPE_FOLDER"], filename)
                file.save(filepath)

                exif = get_exif_data(filepath)
                coords = get_coordinates(exif)

                latitude = None
                longitude = None
                coordinates = None

                # 1. EXIF GPS
                if coords:
                    latitude = str(coords[0])
                    longitude = str(coords[1])
                    coordinates = f"{coords[0]}, {coords[1]}"

                # 2. Browser fallback
                else:
                    lat_form = request.form.get("latitude")
                    lon_form = request.form.get("longitude")

                    if lat_form and lon_form:
                        latitude = lat_form
                        longitude = lon_form
                        coordinates = f"{lat_form}, {lon_form}"

                # 3. Only fallback to server geocoding if NOTHING exists
                if latitude and longitude and not (country or city or street):
                    auto_country, auto_city, auto_street = reverse_geocode(latitude, longitude)
                    country = auto_country
                    city = auto_city
                    street = auto_street

                if country or city or street:
                    location = ", ".join(filter(None, [street, city, country]))
                else:
                    location = "Unknown location"

                add_landscape_item(
                    image_path=f"landscape/{filename}",
                    original_filename=file.filename,
                    location=location,
                    transcription=transcription,
                    comments=comments,
                    content_type=content_type,
                    coordinates=coordinates,
                    latitude=latitude,
                    longitude=longitude
                )

                flash("✨ Thank you! Your wall writing has been added.", "success")
                return redirect(url_for("landscape"))

            except Exception as e:
                error = str(e)

    items = get_all_landscape_items(limit=5)
    return render_template("landscape.html", items=items, error=error)


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOADS_ROOT"], filename)


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)