from database.landscape_repository import add_landscape_item

seed_items = [
    {
        "image_path": "landscape_seed/graffiti1.avif",
        "original_filename": "graffiti1.avif",
        "location": "Athens",
        "language": "Greek",
        "ocr_text": "δώσε τόπο στην οργή",
        "description": "Seed corpus item 1",
        "source_type": "seed",
    },
    {
        "image_path": "landscape_seed/graffiti2.jpg",
        "original_filename": "graffiti2.jpg",
        "location": "Heraklion",
        "language": "Greek",
        "ocr_text": "η πόλη μιλά",
        "description": "Seed corpus item 2",
        "source_type": "seed",
    },
    {
        "image_path": "landscape_seed/graffiti3.jfif",
        "original_filename": "graffiti3.jfif",
        "location": "Thessaloniki",
        "language": "Greek",
        "ocr_text": "κανείς δεν ξεχνά",
        "description": "Seed corpus item 3",
        "source_type": "seed",
    },
    {
        "image_path": "landscape_seed/graffiti4.jpg",
        "original_filename": "graffiti4.jpg",
        "location": "Patras",
        "language": "Greek",
        "ocr_text": "εδώ είναι δρόμος",
        "description": "Seed corpus item 4",
        "source_type": "seed",
    },
    {
        "image_path": "landscape_seed/graffiti5.jfif",
        "original_filename": "graffiti5.jfif",
        "location": "Chania",
        "language": "Greek",
        "ocr_text": "όλα γράφονται στους τοίχους",
        "description": "Seed corpus item 5",
        "source_type": "seed",
    },
]

for item in seed_items:
    add_landscape_item(**item)

print("Landscape seed corpus added.")